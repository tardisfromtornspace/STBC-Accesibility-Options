ShowPercent = 1
ShowBar = 1
ShowFraction = 1
NumberDecimals = 2
RadixNotation = "."
sFont = "Crillee"
FontSize = 5