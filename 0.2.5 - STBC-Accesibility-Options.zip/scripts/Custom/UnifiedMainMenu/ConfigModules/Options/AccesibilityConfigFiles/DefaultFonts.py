# THIS FILE IS NOT SUPPORTED BY ACTIVISION
# THIS FILE IS UNDER THE LGPL LICENSE AS WELL
# DefaultFonts.py
# 1st March 2025, by Alex SL Gato (CharaToLoki)
# Version: 1.0
# Meant to be used alongside the AccesibilityConfig UMM option (located at scripts/Custom/UnifiedMainMenu/ConfigModules/Options/), this file must be under scripts/Custom/UnifiedMainMenu/ConfigModules/Options/AccesibilityConfigFiles
##################################
# This file takes care of listing the default Fonts and Sizes that a regular STBC install supports.
dFont = {
	"Crillee": [5, 6, 9, 12, 15],
	"LCARSText": [5, 6, 9, 12, 15],
	"Tahoma": [8, 14],
	"Arial": [8],
	"Serpentine": [12],
}